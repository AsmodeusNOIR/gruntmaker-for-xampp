	</div>
</section>

<footer class="row"><?php dynamic_sidebar("Footer"); ?></footer>
<a class="exit-off-canvas"></a>

  </div>
</div>
<?php wp_footer(); ?>
</body>
</html>