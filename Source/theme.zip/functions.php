<?php
/*
Author: Ole Fredrik Lie
URL: http://olefredrik.com
*/


// Various clean up functions
require_once('library/cleanup.php'); 

// Required for Foundation to work properly
require_once('library/foundation.php');

// Register all navigation menus
if(!preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])) {
    require_once('library/navigation.php');
} else {
    require_once('library/navigation-ie8.php');
}

// Add menu walker
if(!preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])) {
    require_once('library/menu-walker.php');
} else {
    require_once('library/menu-walker-ie8.php');
}

// Create widget areas in sidebar and footer
require_once('library/widget-areas.php');

// Return entry meta information for posts
require_once('library/entry-meta.php');

// Enqueue scripts
require_once('library/enqueue-scripts.php');

// Add theme support
require_once('library/theme-support.php');

function ltIE8() {
    if (preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT'])) {
        $return = true;
    } else {
        $return = false;
    }
    return $return;
}

function numberToWords ($number) {
  $words = array ('zero',
      'one',
      'two',
      'three',
      'four',
      'five',
      'six',
      'seven',
      'eight',
      'nine',
      'ten',
      'eleven',
      'twelve',
      'thirteen',
      'fourteen',
      'fifteen',
      'sixteen',
      'seventeen',
      'eighteen',
      'nineteen',
      'twenty',
      30=> 'thirty',
      40 => 'forty',
      50 => 'fifty',
      60 => 'sixty',
      70 => 'seventy',
      80 => 'eighty',
      90 => 'ninety',
      100 => 'hundred',
      1000=> 'thousand');
 
  if (is_numeric ($number))
  {
    $number = (int) round($number);
    if ($number < 0)
    {
      $number = -$number;
      $number_in_words = 'minus ';
    }
    if ($number > 1000)
    {
      $number_in_words = $number_in_words . numberToWords(floor($number/1000)) . " " . $words[1000];
      $hundreds = $number % 1000;
      $tens = $hundreds % 100;
      if ($hundreds > 100)
      {
        $number_in_words = $number_in_words . ", " . numberToWords ($hundreds);
      }
      elseif ($tens)
      {
        $number_in_words = $number_in_words . " and " . numberToWords ($tens);
      }
    }
    elseif ($number > 100)
    {
      $number_in_words = $number_in_words . numberToWords(floor ($number / 100)) . " " . $words[100];
      $tens = $number % 100;
      if ($tens)
      {
        $number_in_words = $number_in_words . " and " . numberToWords ($tens);
      }
    }
    elseif ($number > 20)
    {
      $number_in_words = $number_in_words . " " . $words[10 * floor ($number/10)];
      $units = $number % 10;
      if ($units)
      {
        $number_in_words = $number_in_words . numberToWords ($units);
      }
    }
    else
    {
      $number_in_words = $number_in_words . " " . $words[$number];
    }
    return $number_in_words;
  }
  return false;
}

?>