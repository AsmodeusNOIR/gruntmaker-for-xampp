<?php

if (!function_exists('FoundationPress_scripts')) :
  function FoundationPress_scripts() {

    if(ltIE8()) {
        
        // deregister the jquery version bundled with wordpress
        wp_deregister_script( 'jquery' );
        
        // enqueue modernizr, jquery and foundation
        wp_register_script( 'modernizr', get_template_directory_uri() . '/js/foundation3/modernizr.foundation.js', array(), '1.0.0', false );
        wp_register_script( 'jquery', get_template_directory_uri() . '/js/foundation3/jquery.js', array(), '1.0.0', true );
        wp_register_script( 'foundation', get_template_directory_uri() . '/js/foundation3/app.js', array('jquery'), '1.0.0', true );
        wp_register_script( 'ie8-nav', get_template_directory_uri() . '/js/foundation3/jquery.foundation.navigation.js', array('jquery'), '1.0.0', true );
        wp_register_script( 'ie8-topbar', get_template_directory_uri() . '/js/foundation3/jquery.foundation.topbar.js', array('jquery'), '1.0.0', true );

        wp_enqueue_script( 'modernizr' );
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'foundation' );
        wp_enqueue_script( 'ie8-nav' );
        wp_enqueue_script( 'ie8-topbar' ); 
        
    } else {
        
        // deregister the jquery version bundled with wordpress
        wp_deregister_script( 'jquery' );
        
        // enqueue modernizr, jquery and foundation
        wp_register_script( 'modernizr', get_template_directory_uri() . '/js/modernizr/modernizr.min.js', array(), '1.0.0', false );
        wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery/dist/jquery.min.js', array(), '1.0.0', true );
        wp_register_script( 'foundation', get_template_directory_uri() . '/js/app.js', array('jquery'), '1.0.0', true );

        wp_enqueue_script( 'modernizr' );
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'foundation' );   
         
    }

  }

  add_action( 'wp_enqueue_scripts', 'FoundationPress_scripts' );
endif;

function kitchensink_scripts() {
  if ( is_page_template('kitchen-sink.php') ) {

    wp_enqueue_script( 'kitchen-sink', get_template_directory_uri() . '/js/kitchen-sink.js', array('jquery'), '1.0.0', true );

  }
}

add_action( 'wp_enqueue_scripts', 'kitchensink_scripts' );


?>