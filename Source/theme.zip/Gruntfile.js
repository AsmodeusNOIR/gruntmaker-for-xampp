module.exports = function(grunt) {
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),

		sass: {
		  options: {
			includePaths: ['bower_components/foundation/scss']
		  },
		  dist: {
			options: {
			  outputStyle: 'compressed'
			},
			files: {
			  'css/app.css': 'scss/app.scss'
			}        
		  }
		},

		copy: {
		  main: {
			expand: true,
			cwd: 'bower_components',
			src: '**',
			dest: 'js'
		  },
		},

		uglify: {
		  dist: {
			files: {
			  'js/modernizr/modernizr.min.js': ['js/modernizr/modernizr.js']
			}
		  }
		},

		concat: {
		  options: {
			separator: ';',
		  },
		  dist: {
			src: [
			  'js/foundation/js/foundation.min.js',
			  'js/init-foundation.js'
			],

			dest: 'js/app.js',
		  },

		},

		imagemin: {
			out: {
				files: [{
					expand: true,
					cwd: '_img/',
					src: ['**/*.{png,jpg,gif}'],
					dest: 'images/'
				}]
			}
		},

		watch: {
		  grunt: { files: ['Gruntfile.js'] },

		  sass: {
			files: 'scss/**/*.scss',
			tasks: ['sass']
		  },		  
		  images: {
			files: '_img/**/*.{png,gif,jpg}',
			tasks: ['imagemin']
		  }
		}
	});

	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-imagemin');
	grunt.loadNpmTasks('grunt-sass');
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-contrib-copy');
	grunt.loadNpmTasks('grunt-contrib-watch');

	grunt.registerTask('build', ['sass','imagemin']);
	grunt.registerTask('default', ['copy', 'uglify', 'concat', 'watch']);

}