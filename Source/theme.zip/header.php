<!doctype html>
<?php
    $headerClass = 'no-js';
    if(ltIE8()) {
        $headerClass .= ' ie8-custom';
    }
?>
<html class="<?php echo $headerClass; ?>" <?php language_attributes(); ?> >
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php include(locate_template('parts/title.php')); ?></title>
    
    <?php if(ltIE8()) { ?>
        <script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js"></script>
        <script src="//s3.amazonaws.com/nwapi/nwmatcher/nwmatcher-1.2.5-min.js"></script>
        <script src="//html5base.googlecode.com/svn-history/r38/trunk/js/selectivizr-1.0.3b.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
    <?php } ?>
    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/visibility.css" />
    <?php if(!ltIE8()) { ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/offcanvas.css" />
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/foundation.css" />
    <?php } else { ?>
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/foundation3/foundation.css" />
    <?php } ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/normalize.css" />
    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/main.css" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie8-visibility.css" />
    
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/img/icons/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo get_template_directory_uri(); ?>/assets/img/icons/apple-touch-icon-144x144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo get_template_directory_uri(); ?>/assets/img/icons/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo get_template_directory_uri(); ?>/assets/img/icons/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo get_template_directory_uri(); ?>/assets/img/icons/apple-touch-icon-precomposed.png">
    
    <?php wp_head(); ?>
  </head>
  
  <body <?php body_class(); ?>>
  <?php if (!ltIE8()) { ?>
      <div class="off-canvas-wrap">
      <div class="inner-wrap">

      <nav class="tab-bar show-for-small-only">
        <section class="left-small">
          <a class="left-off-canvas-toggle menu-icon" ><span></span></a>
        </section>
        <section class="middle tab-bar-section">

          <h1 class="title"><?php bloginfo( 'name' ); ?></h1>

        </section>
      </nav>

      <aside class="left-off-canvas-menu">
        <?php foundationPress_mobile_off_canvas(); ?>
      </aside>
  <?php } ?>
  
    <header class="row" role="banner">
        <div class="small-12 columns">
            <h1><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>
            <h4 class="subheader"><?php bloginfo('description'); ?></h4>
            <hr/>
        </div>
    </header>
  
  <?php if (!ltIE8()) { ?>
        <div class="top-bar-container contain-to-grid show-for-medium-up">
            <nav class="top-bar" data-topbar="">
                <ul class="title-area">
                    <li class="name">
                        <h1><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></h1>
                    </li>          
                </ul>
                <section class="top-bar-section">
                    <?php foundationPress_top_bar_l(); ?>
                </section>
            </nav>
        </div>
  <?php } else { ?>
      <div class="top-bar-container contain-to-grid show-for-medium-up">
          <?php foundationPress_top_bar_l(); ?>
      </div>
  <?php } ?>

<section class="container" role="document">
  <div class="row">